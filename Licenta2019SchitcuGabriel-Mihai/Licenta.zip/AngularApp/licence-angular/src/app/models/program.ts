export interface Program {
    id: string;
    name: string;
    pending: boolean;
    }

