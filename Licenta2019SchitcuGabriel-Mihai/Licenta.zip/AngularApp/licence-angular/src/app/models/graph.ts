export interface Graph {
  id: string;
  name: string;
  pending: boolean;
}
