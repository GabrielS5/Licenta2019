export const environment = {
  production: false,
  urlAddress: 'http://localhost:51221/api'
};
