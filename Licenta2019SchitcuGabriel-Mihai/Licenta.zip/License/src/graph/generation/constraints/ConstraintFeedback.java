package graph.generation.constraints;

public enum ConstraintFeedback {
	Revert, Complete, Incomplete
}
