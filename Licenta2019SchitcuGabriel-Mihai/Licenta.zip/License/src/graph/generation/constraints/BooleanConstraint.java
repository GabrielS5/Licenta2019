package graph.generation.constraints;

public abstract class BooleanConstraint extends Constraint {

}
