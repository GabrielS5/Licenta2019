package editors;

public enum EditorType {
	Code, Graph
}
