package editors;

	public enum GraphEditMode {
		AddingNodes,
		AddingEdges,
		EditingValues,
		Deleting
	}

	
	