package tools;

public enum RunningMode {
	Manual, Automatic, Pause, Exit
}
