﻿namespace LicenceAPI.Models
{
    public class EntityDTO
    {
        public string Name { get; set; }
        
        public string Text { get; set; }
    }
}
