﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LicenceAPI.Models
{
    public class Blob
    {
        public string Text { get; set; }
    }
}
