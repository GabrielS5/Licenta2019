import graph.Graph;
import tools.Program;

public class Program extends Program {
	
	@Override
	public void run(Graph graph) {
		for(int i = 0; i< 10000;i++){
		print(i);
		}
	}
}